const nomeMesi = ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno",
"Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"];
var dataAttuale = new Date()
var giorno = dataAttuale.getDate();
var anno = dataAttuale.getFullYear();
var mesi = dataAttuale.getMonth();
var btn = document.getElementById('oraAttuale');
var ora;


btn.addEventListener('click', function () {
    ora = document.getElementById('ora').value;
    verifica()
});
function verifica() {
   if (ora < 10) {
    document.getElementById('salutami').innerHTML = 'Buongiorno';
   } else if (ora < 20) {
    document.getElementById('salutami').innerHTML = 'BuonPomeriggio';
   } else {
    document.getElementById('salutami').innerHTML = 'Buonasera';
   }
};
 
document.getElementById('dataOggi').innerHTML = giorno + "/" + nomeMesi[dataAttuale.getMonth()] + "/" + anno;

document.getElementById('dataCompleta').innerHTML = dataAttuale;
document.getElementById('giorno').innerHTML += giorno;
document.getElementById('mese').innerHTML += nomeMesi[dataAttuale.getMonth()]
document.getElementById('dataStandard').innerHTML += " " +  giorno + "-" + mesi + "-" + anno;
